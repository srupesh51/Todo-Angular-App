'use strict'
const app = require('./server')
exports.handler = app
